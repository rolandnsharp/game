Inside this archive, you'll find some interesting data. Look for a file named 'secret_formula.txt'
